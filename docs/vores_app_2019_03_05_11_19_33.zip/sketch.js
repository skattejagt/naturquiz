function setup() {
let button = createButton('START').parent('knapper');
  button.attribute('class', 'button');
 // button.mousePressed(changeBG);
  
}

/*function changeBG() {
  let val = random(255);
  background(val);
}
*/

function draw() {
 
}